import UIKit

var msg = "You can do it"
msg[msg.startIndex]
msg[msg.index(after:msg.startIndex)]
msg[msg.index(before:msg.endIndex)]
for index in msg.indices{
    print("\(msg[index])")
}
let ind = msg.index(msg.startIndex,offsetBy:4)
//print(msg[ind])
msg.insert("!",at:msg.endIndex)
var s1 = "Abhsihek"
msg.insert(contentsOf: s1,at:msg.index(before:msg.endIndex))
 var arr: [Int] = []
print(arr.count)
arr.append(4)
print(arr)
var ele = Array(repeating:4,count:4)
print(ele)
var ele2 = Array(repeating : 56,count:4)
var ele22 = ele + ele2
print(ele22)
let motivation :[String] = ["Discipline","positive-attitude","keep-hustling"]
for _ in motivation {
    print()
}
var weekend:[String] = ["home","study","rest"]
print(weekend.count)
if weekend.isEmpty{
    print("Add some task in weekend")
}else{
    print("lot to do")
}
weekend.append("complete-first-module")
print(weekend)
weekend += ["exercise","swift-videos","codeacademy"]
print(weekend)
 
let x = [["ios,swift"],["Uikit","swiftui"],["cooca","spm"]]
let res = Array(x.joined())
print(res)
 
//var ans : Character = "A"
//print(ans)

let simpleclousre = {
    print("this is clousre")
}
simpleclousre()
let anotherclosure:(String) -> () = { name in
    print(name)
    
}
anotherclosure("AbhishekChoudhary")
let closurree : (String) -> (String) = { msg in
    let greet = msg + " " + "ios-developer";
    return greet
}
print(closurree("Abhishek Choudhary"))
// here we have passed closure in function as a parameter.

let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
var reveresNames = names.sorted(by: {( s1 :String, s2:String) -> Bool in
    return s1 < s2
})
print(reveresNames)

// Type inference from context
// no need to give parameter and return type
// swift will manage that as names is a string..
var reveresNamess = names.sorted(by: {( s1, s2) in s1 > s2
})
print(reveresNamess)
// shorthand type, we can access parameter using $..
var shorthand = names.sorted(by: {$0 > $1 })
print(shorthand)
 
// trailing closures
func randomtest( computation : Int,closure:() -> Void ) {
  var temp = computation
    temp = temp*temp*temp
    closure()
    print(temp)
}
randomtest(computation : 10){
    print("this is trailing closure")
}

// if function has only closure as a paramete

func onlyparamter(closure:() -> Void ) {
  
    var temp = 25
    temp +=   10
    closure()
    print(temp)
}
onlyparamter {print("only parameter is closuer")}

// correct version

class human{
    var eyes : Int
    var legs : Int
    init(eyes : Int, legs : Int){
        self.eyes = eyes
        self.legs = legs
    }
    convenience init(){
        self.init(eyes: 2,legs: 4)
    }
}
var a = human()
print(a.eyes)
print(a.legs)
 

func someoffirst(closure : @escaping (Int)-> (Int)){
    var sum = closure(10)
    print("escaping")
    //let duration = UInt64(s* 1_000_000_000)
          // try await Task.sleep(nanoseconds: 1000)
    print(sum)
}

someoffirst(closure: { a in
     var res = a*a
    return res
})
   

someoffirst() { a in // when no extra parameter is there
     var res = a*a   // except a closure.......
    return res
}

someoffirst { a in  // since there is only one variable we
     var res = a*a  // we can omit paranthesis here .....
    return res
}



func factorial(a:Int,closure2 : (Int) -> Int){
    //print("factorial of number is")
    var fact = closure2(a)
    print("factorial of number is \(fact)")
}

factorial(a:10)  {
     n in
    var result = 1
       if(n > 0) {
           for i in 1...n {
               result *= i
           }
       }
       return result
    
}
 
func factorial(s1:String, closure3 : @escaping(Int) ->(Int)){
    
    let fact = closure3(10)
    print(s1 + "\(fact)")
}

factorial(s1: "factorial is:") {
    n in
    var result = 1
    if(n > 0) {
        for i in 1...n {
            result *= i
        }
    }
    return result
}

// implementation of properties.....
// stored properties.....
struct fixedLengthRange{
    var firstValue: Int
    let length : Int
}
var rangeofThreeItems = fixedLengthRange(firstValue:0 ,length:3)
rangeofThreeItems.firstValue = 6
// stored property of constant instances ...
let rangeFourItems = fixedLengthRange(firstValue: 0,length: 4)
/* if we try to change the firstValue it will report an
 error as it is a constant defned by a let */

// Lazy properties....
/* lazy stored property whose intial value is not calculated
 until the first time it is used.
 lazy property are useful when the intial value of a property
 is dependent
 */

class DataImporter {
    var filename = "data.txt"
    
}
class DataManager{
    lazy var  importer = DataImporter()
    var data : [String] = []
}
let manager = DataManager()
manager.data.append("Some data")
manager.data.append("Some more data")
print(manager.data)
// computed properties starts here .....
/* they don't store values rather they provide getter and
 setter method to retrieve and set property and values indirectly.
 */

class Efforts {
    var timeleft : Int = 20
    var dailystudy : Int = 1
    var timerequired : Int = 90
    var effortRequired : Int {
        get {
            return (timerequired/dailystudy)*timeleft
        }
        set {
            timerequired = newValue/10
            dailystudy = timerequired/180
            timeleft = effortRequired - timerequired
        }
    }
}

var obj = Efforts()
print(obj.effortRequired)
obj.effortRequired = 1800
print(obj.timerequired)
print(obj.timeleft)
print(obj.dailystudy)



