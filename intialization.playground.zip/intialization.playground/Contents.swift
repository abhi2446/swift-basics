import UIKit

struct celsius {
    var temperature : Double
    init(ferenhiet: Double){
        temperature = (ferenhiet-32.0)/1.8
    }
    init(kelvin: Double){
        temperature = kelvin - 273.15
    }
}
let boilingpoint = celsius(ferenhiet: 212.0)
print(boilingpoint)

struct percg {
    var per : Double
    var cg : Double
    init(cg:Double){
        self.cg = cg
        per = cg*9.5
    }
    init(per: Double) {
        self.per = per
        cg = per/9.5
    }
}

var obj1 = percg(cg: 8.32)
print(obj1.per)
print(obj1.cg)
var obj2 = percg(per: 86.6)
print(obj2.cg)
print(obj2.per)

struct intern {
    var id : Double?
    var name : String
    var age : Int
    init(id:Double,name:String,age:Int){
        self.id = id
        self.name = name
        self.age = age
    }
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    
}
var test = intern(id: 24.24, name: "Abhi", age: 21)
print(test)
var obj3 = intern(name: "Abhishek-Choudhary", age: 22)
print(obj3)

class demo {
    var model: Int
    var name: String
    var number: Double
    init(model:Int,name:String,number: Double){
        self.model = model
        self.name = name
        self.number = number
    }
    convenience init(name: String) {
        self.init(model: 1998, name: name, number: 5000.0)
        self.name = name
    }
}
var objjj = demo(name: "bullet")
print(objjj.name)
print(objjj.model)
 
struct Rectangle {
    var width = 10
    var height = 10
    var area : Int {
        get{
            return width*height
        }
        set{
            self.area = 0
        }
    }
}
 var rectangle = Rectangle()
print(rectangle.area)
rectangle.width = 20
rectangle.height = 20
var rect = rectangle
rect.width = 30
print(rectangle.width)

